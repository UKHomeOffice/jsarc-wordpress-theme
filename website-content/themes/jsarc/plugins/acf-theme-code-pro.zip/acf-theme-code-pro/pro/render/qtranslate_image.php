<?php
// qTranslate - Image field

// Same as ACF core image field

include( ACFTCP_Core::$plugin_path . 'render/image.php' );
