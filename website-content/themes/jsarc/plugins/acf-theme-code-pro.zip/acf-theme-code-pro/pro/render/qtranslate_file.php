<?php
// qTranslate File field

// Same as ACF core file field

include( ACFTCP_Core::$plugin_path . 'render/file.php' );
